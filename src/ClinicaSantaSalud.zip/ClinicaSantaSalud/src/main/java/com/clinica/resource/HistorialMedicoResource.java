
package com.clinica.resource;

import com.clinica.dao.HistorialMedicoDAO;
import com.clinica.model.HistorialMedico;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Path("/historiales")
public class HistorialMedicoResource {
	
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<HistorialMedico> listar() {
    	return new HistorialMedicoDAO().listar();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response registrar(HistorialMedico historial) {
    	boolean creado = new HistorialMedicoDAO().registrar(historial);
        return creado ? Response.status(Response.Status.CREATED).build() :
                        Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
    }
}
