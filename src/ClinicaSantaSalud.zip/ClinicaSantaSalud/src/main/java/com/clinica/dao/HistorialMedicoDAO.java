
package com.clinica.dao;

import com.clinica.model.HistorialMedico;
import com.clinica.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HistorialMedicoDAO {

    public List<HistorialMedico> listar() {
        List<HistorialMedico> lista = new ArrayList<>();
        String sql = "SELECT * FROM historial_medico";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                HistorialMedico h = new HistorialMedico();
                h.setId(rs.getInt("id"));
                h.setPacienteId(rs.getInt("paciente_id"));
                h.setCitaId(rs.getInt("cita_id"));
                h.setDiagnostico(rs.getString("diagnostico"));
                h.setTratamiento(rs.getString("tratamiento"));
                h.setFechaRegistro(rs.getString("fecha_registro"));
                lista.add(h);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean registrar(HistorialMedico h) {
        String sql = "INSERT INTO historial_medico (paciente_id, cita_id, diagnostico, tratamiento) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, h.getPacienteId());
            stmt.setInt(2, h.getCitaId());
            stmt.setString(3, h.getDiagnostico());
            stmt.setString(4, h.getTratamiento());
            return stmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
