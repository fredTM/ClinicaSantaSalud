package com.clinica.model;

public class Paciente {
    private int id;
    private String nombre;
    private String apellido;
    private String dni;
    private String telefono;
    private String correo;
    private String fechaNacimiento;
    private String direccion;

    public Paciente() {}

    public Paciente(int id, String nombre, String apellido, String dni, String telefono, String correo, String fechaNacimiento, String direccion) {
        this.setId(id);
        this.setNombre(nombre);
        this.setApellido(apellido);
        this.setDni(dni);
        this.setTelefono(telefono);
        this.setCorreo(correo);
        this.setFechaNacimiento(fechaNacimiento);
        this.setDireccion(direccion);
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

    // Getters y setters de todos...
}
