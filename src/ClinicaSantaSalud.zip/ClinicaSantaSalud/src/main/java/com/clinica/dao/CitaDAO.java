
package com.clinica.dao;

import com.clinica.model.Cita;
import com.clinica.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CitaDAO {

    public List<Cita> listar() {
        List<Cita> lista = new ArrayList<>();
        String sql = "SELECT * FROM citas";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Cita c = new Cita();
                c.setId(rs.getInt("id"));
                c.setPacienteId(rs.getInt("paciente_id"));
                c.setMedicoId(rs.getInt("medico_id"));
                c.setConsultorioId(rs.getInt("consultorio_id"));
                c.setFecha(rs.getString("fecha"));
                c.setMotivo(rs.getString("motivo"));
                c.setEstado(rs.getString("estado"));
                lista.add(c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean registrar(Cita cita) {
        String sql = "INSERT INTO citas (paciente_id, medico_id, consultorio_id, fecha, motivo, estado) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, cita.getPacienteId());
            stmt.setInt(2, cita.getMedicoId());
            stmt.setInt(3, cita.getConsultorioId());
            stmt.setString(4, cita.getFecha());
            stmt.setString(5, cita.getMotivo());
            stmt.setString(6, cita.getEstado());
            return stmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
