
package com.clinica.resource;

import com.clinica.dao.CitaDAO;
import com.clinica.model.Cita;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Path("/citas")
public class CitaResource {

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Cita> listar() {
    	return new CitaDAO().listar();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response registrar(Cita cita) {
    	boolean creado = new CitaDAO().registrar(cita);
        return creado ? Response.status(Response.Status.CREATED).build() :
                        Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
    }
}
