
package com.clinica.resource;

import com.clinica.dao.PacienteDAO;
import com.clinica.model.Paciente;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Path("/pacientes")
public class PacienteResource {

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Paciente> listar() {
        return new PacienteDAO().listarPacientes();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response registrar(Paciente paciente) {
        boolean creado = new PacienteDAO().registrarPaciente(paciente);
        return creado ? Response.status(Response.Status.CREATED).build() :
                        Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
    }
}
