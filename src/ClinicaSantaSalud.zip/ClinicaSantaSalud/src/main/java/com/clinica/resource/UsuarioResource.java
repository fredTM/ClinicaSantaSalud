
package com.clinica.resource;

import com.clinica.dao.UsuarioDAO;
import com.clinica.model.Usuario;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/usuarios")
public class UsuarioResource {

    private final UsuarioDAO dao = new UsuarioDAO();

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response registrar(Usuario usuario) {
        if (usuario.getUsuario() == null || usuario.getContraseña() == null) {
            return Response.status(Response.Status.BAD_REQUEST).entity("Usuario y contraseña son obligatorios").build();
        }
        boolean creado = dao.registrar(usuario);
        return creado ? Response.status(Response.Status.CREATED).build() :
                        Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
    }

    @POST
    @Path("/login")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response login(Usuario datos) {
        Usuario user = dao.login(datos.getUsuario(), datos.getContraseña());
        if (user != null) {
            user.setContraseña("");
            return Response.ok(user).build();
        } else {
            return Response.status(Response.Status.UNAUTHORIZED).entity("Credenciales incorrectas").build();
        }
    }
}
