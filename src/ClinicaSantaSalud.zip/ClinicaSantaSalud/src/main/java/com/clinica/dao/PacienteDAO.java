package com.clinica.dao;

import com.clinica.model.Paciente;
import com.clinica.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PacienteDAO {

    // LISTAR TODOS
    public List<Paciente> listarPacientes() {
        List<Paciente> pacientes = new ArrayList<>();
        String sql = "SELECT * FROM pacientes";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Paciente p = new Paciente(
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("apellido"),
                    rs.getString("dni"),
                    rs.getString("telefono"),
                    rs.getString("correo"),
                    rs.getString("fecha_nacimiento"),
                    rs.getString("direccion")
                );
                pacientes.add(p);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return pacientes;
    }

    // BUSCAR POR ID
    public Paciente getPaciente(int id) {
        Paciente paciente = null;
        String sql = "SELECT * FROM pacientes WHERE id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    paciente = new Paciente(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("dni"),
                        rs.getString("telefono"),
                        rs.getString("correo"),
                        rs.getString("fecha_nacimiento"),
                        rs.getString("direccion")
                    );
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return paciente;
    }

    // INSERTAR
    public boolean registrarPaciente(Paciente paciente) {
        String sql = "INSERT INTO pacientes (nombre, apellido, dni, telefono, correo, fecha_nacimiento, direccion) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, paciente.getNombre());
            stmt.setString(2, paciente.getApellido());
            stmt.setString(3, paciente.getDni());
            stmt.setString(4, paciente.getTelefono());
            stmt.setString(5, paciente.getCorreo());
            stmt.setString(6, paciente.getFechaNacimiento());
            stmt.setString(7, paciente.getDireccion());

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // ACTUALIZAR
    public boolean actualizarPaciente(Paciente paciente) {
        String sql = "UPDATE pacientes SET nombre = ?, apellido = ?, dni = ?, telefono = ?, correo = ?, fecha_nacimiento = ?, direccion = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, paciente.getNombre());
            stmt.setString(2, paciente.getApellido());
            stmt.setString(3, paciente.getDni());
            stmt.setString(4, paciente.getTelefono());
            stmt.setString(5, paciente.getCorreo());
            stmt.setString(6, paciente.getFechaNacimiento());
            stmt.setString(7, paciente.getDireccion());
            stmt.setInt(8, paciente.getId());

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // ELIMINAR
    public boolean eliminarPaciente(int id) {
        String sql = "DELETE FROM pacientes WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
